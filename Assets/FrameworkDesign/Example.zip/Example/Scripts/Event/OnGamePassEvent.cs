namespace FrameworkDesign.Example
{
    public struct OnGamePassEvent
    {
    }
}