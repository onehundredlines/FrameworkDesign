namespace FrameworkDesign.Example
{
    public struct OnMissEvent
    {
    }
}