namespace FrameworkDesign.Example
{
    public struct OnKillEnemyEvent
    {
    }
}