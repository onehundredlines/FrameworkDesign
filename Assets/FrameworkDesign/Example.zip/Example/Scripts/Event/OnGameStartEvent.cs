﻿namespace FrameworkDesign.Example
{
    public struct OnGameStartEvent
    {
    }
}